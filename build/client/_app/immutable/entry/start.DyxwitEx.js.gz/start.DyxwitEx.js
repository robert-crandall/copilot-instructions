import{l as o,d as r}from"../chunks/BnM-H2vA.js";export{o as load_css,r as start};
